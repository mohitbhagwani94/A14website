<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=no">
		<title>Aaruush 2014</title>
		<link rel="shortcut icon" href="img/iPad.png"/>
		<link rel="stylesheet" href="http://code.jquery.com/mobile/1.3.2/jquery.mobile-1.3.2.min.css" />
		<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
		<script src="http://code.jquery.com/mobile/1.3.2/jquery.mobile-1.3.2.min.js"></script>
	</head>
	<body>
		<div data-role="page">
		<div data-role="popup" id="menu" data-theme="d">
				<ul data-role="listview" data-inset="true" style="min-width:210px;">
					<li data-role="divider" data-theme="e">
						Menu
					</li>
					<li>
						<a href="index.php" data-transition="slide">Home</a>
					</li>
					<li>
						<a href="domains.php" data-transition="slide">Domains</a>
					</li>
					<li>
						<a href="workshops.php" data-transition="slide">Workshops</a>
					</li>
					<li>
						<a href="highlights.php" data-transition="slide">Highlights</a>
					</li>
					<li>
						<a href="contact_us.php" data-transition="slide" data-ajax="false">Contact Us</a>
					</li>

					<li>
						<a href="credits.php" data-transition="slide" >Credits</a> 
					</li>
				</ul>
			</div>
			<div data-role="header" data-theme="c">
				<a data-role="button" data-inline="true" data-rel="back" data-transition="slide" data-icon="back" data-iconpos="left"> Back </a>
				<h1><a><img src="img/iPad.png" width="30px" height="25px" /></a>Aaruush '14</h1>
				<a href="#menu" class="ui-btn-right" data-icon="grid" data-iconpos="notext" data-rel="popup" data-transition="slideup"></a>
				<!--<a href="#menu" class="ui-btn-right" data-icon="grid" data-iconpos="notext" data-rel="dialog" data-transition="pop"></a>-->
			</div><!-- /header -->
			<div data-role="content">
				<h1 style="font-variant:small-caps" align="center"> Who Killed Pyarelal </h1>
				<div data-role="collapsible-set">
					<div data-role="collapsible" data-collapsed="false">
						<h3> Introduction </h3>
						<p align="justify">
							Heat exchangers, distillation columns, reactors, so on and so forth. Solve the everyday problems faced by a process and design engineer. Do you want to become a design or a process engineer? Yours, Chemically is the perfect event to scope your talents and interests.  Save your make believe industry and help rebuild it to its former stature and prove your mettle while you are at it.  
						</p>
					</div>
					<div data-role="collapsible" data-collapsed="true">
						<h3> Details </h3>
						<div align="justify">
							<h3>Round 1:CROSS THE BARRIER</h3>

							
Activation energy..sound familiar? This is a theme based round. A reaction will be given. And it will have to reach threshold energy for the reaction to take place. Each question
the participant answers will have a certain energy value. The goal is to make the reaction occur.

							<h3>Round 2:BALANCE IT OUT</h3>
							
 
Balances are something that has been used for almost everything. Be it a normal chemical equation balance or a weight balance in a lab, balancing is what we engineers are best at. Rack your brains with simple balancing equations, with a twist.
							<h3>Round 3:WHAT WENT WRONG?</h3>

A situation will be given to each team. Each situation will be a prominent disaster that took place. A part of the situation will be given where a major engineering failure would have occurred. Finding what went wrong is the task. Eg: BP oil spill disaster was caused by a mechanical failure which occurred due to excessive pressure build up.

<h3>SAVE YOUR INDUSTRY</h3>
Industry.. Isn’t that the dream of every design and process
oriented engineer? But, your industry is in danger. The solution to its safety lies in your knowledge bank and the tiny grey cells in your brain.
							</div>

					</div>
					<div data-role="collapsible" data-collapsed="true">
						<h3> Co-ordinator Details </h3>
						<p>
							<b>  </b>
							<h5></h5>
							
						</p>
					</div>
				</div>
			</div><!-- /content -->

			<div data-role="footer" data-theme="c">
				<center><img src="img/webarch.png" /></center>
				<!--<h1>&lt;&lt;&nbsp;WebArch&nbsp;&gt;&gt;</h1>-->
			</div><!-- /Footer -->
		</div><!-- /page -->
	</body>
</html>